============================================================================
CONTENTS OF THIS FILE
============================================================================
* Dependencies
* Installation
* Configuration and features

============================================================================
DEPENDENCIES
============================================================================
1, Ctools
2. Features

============================================================================
INSTALLATION
============================================================================
Quite simple, Download the module and simply put into your 
your_drupal_path/sites/all/modules and install from your admin panel.


============================================================================
CONFIGURATION AND FEATURES
============================================================================
After successfull installation you able to export your all local box from
Admin >> Structure >> Features >> Create Features

Enter your features name, description, package(optional),
version(optional), URL(optional) and then choose "Block: blockexport_settings"
from edit components drop-down box and then should check
"Block: Export All Blocks" checkbox and then press download button.

Unzip your downloaded file and upload it into your drupal installed remote
server or in any vanila drupal(drupal_root/sites/all/modules) where you want
to import all the exported blocks and enable this module by drush or
from admin.

Thats it.
